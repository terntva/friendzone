import React from "react";

export default function Footer() {
    return (
        <footer>
            Friendzone - интернет-магазин товаров для вашего компьютера с возможностью дарить подарки друзьям и близким людям.
            <div>
                Все права защищены &copy;
            </div>
        </footer>
    )
}